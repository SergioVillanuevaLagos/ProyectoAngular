import { Component } from '@angular/core';
import { Locacion } from '../../models/locacion.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'] // Cambia styleUrl por styleUrls
})
export class HomeComponent {

}
