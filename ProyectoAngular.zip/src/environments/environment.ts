export const environment = {
  production: false,
  googleOAuthConfig: {
    clientId: '176637695859-bjmoc0gsne359tjtbo70p6g40c2ti4pk.apps.googleusercontent.com',
    redirectUri: 'http://localhost:4200/main'
  }
};
